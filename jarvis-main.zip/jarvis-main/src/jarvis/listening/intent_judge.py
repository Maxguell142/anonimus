"""LLM-based intent judge for voice assistant.

Receives full context (transcript buffer, TTS history, state) and makes
informed decisions about whether speech is directed at the assistant and
what the actual query is. Routes through ``jarvis.llm.get_llm_backend``
so the active provider (Ollama, OpenAI-compatible) handles the call.
"""

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Optional, List

from ..debug import debug_log
from ..llm import get_llm_backend, resolve_model, Tier
from .transcript_buffer import TranscriptSegment


DEFAULT_OLLAMA_KEEP_ALIVE = "30m"
LOW_POWER_OLLAMA_KEEP_ALIVE = "1m"


def _is_low_power_mode_enabled(cfg: Any) -> bool:
    """Return True only when Settings.low_power_mode is explicitly enabled."""
    if cfg is None:
        return False
    return getattr(cfg, "low_power_mode", False) is True


def _ollama_keep_alive_for_power_mode(cfg: Any) -> str:
    """Return the Ollama residency duration for the active power mode."""
    if _is_low_power_mode_enabled(cfg):
        return LOW_POWER_OLLAMA_KEEP_ALIVE
    return DEFAULT_OLLAMA_KEEP_ALIVE


def warm_up_chat_model(cfg, model: str, timeout: float) -> bool:
    """Page ``model`` into the active backend's resident memory.

    Thin wrapper over :meth:`LLMBackend.warm_up` so callers don't need to
    construct a backend just to ask for a warmup. Returns whatever the
    backend's warmup result is — on an Ollama backend this sends a real
    inference with ``keep_alive``; on an OpenAI-compatible backend it
    also sends a minimal inference to force model loading (no longer a
    no-op). A failed warmup is informational and never blocks operation.
    """
    if not model:
        return False
    try:
        ok = get_llm_backend(cfg).warm_up(
            model,
            timeout_sec=timeout,
            keep_alive=_ollama_keep_alive_for_power_mode(cfg),
        )
    except Exception as e:
        debug_log(f"warmup error (model={model}): {e}", "voice")
        return False
    debug_log(
        f"warmup {'ok' if ok else 'failed'} (model={model})",
        "voice",
    )
    return ok


def _extract_json_object(text: str, last: bool = False) -> str:
    """Return a balanced `{...}` object in `text`, or "" if none.

    Walks character-by-character tracking brace depth while respecting string
    literals and escapes. Handles markdown code fences and values containing
    braces — cases a simple regex cannot.

    Returns the first balanced object by default, or the **last** when
    ``last=True`` — used for reasoning-model recovery, where the answer sits
    at the end of the thinking text and earlier balanced objects may be
    echoes of the system prompt's JSON example rather than the verdict.
    Unbalanced objects are skipped so a truncated draft cannot hide a later
    complete answer.
    """
    candidates: list[str] = []
    search_from = 0
    while True:
        start = text.find("{", search_from)
        if start == -1:
            break
        depth = 0
        in_string = False
        escape = False
        end = -1
        for i in range(start, len(text)):
            ch = text[i]
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        if end == -1:
            # Unbalanced from this `{` — skip it and keep scanning for a
            # later complete object.
            search_from = start + 1
            continue
        candidates.append(text[start:end])
        search_from = end
    if not candidates:
        return ""
    return candidates[-1] if last else candidates[0]


@dataclass
class IntentJudgment:
    """Result of intent judgment."""

    directed: bool           # Is this speech directed at the assistant?
    query: str               # Extracted query (cleaned of filler, echo, pre-wake-word)
    stop: bool               # Is this a stop command?
    confidence: str          # "high", "medium", or "low"
    reasoning: str           # Brief explanation for debugging
    raw_response: str = ""   # Raw LLM response for debugging


@dataclass
class IntentJudgeConfig:
    """Configuration for the intent judge.

    ``cfg`` is the Jarvis Settings object (or any duck-type with the same
    LLM provider attributes); the judge dispatches every chat call through
    ``get_llm_backend(cfg)``. ``model`` carries the per-call model name
    (the fast tier: ``resolve_model(cfg, Tier.FAST)``).
    """

    assistant_name: str = "Jarvis"
    aliases: list = field(default_factory=list)
    model: str = "gemma4:e2b"
    cfg: Any = None
    timeout_sec: float = 15.0
    thinking: bool = False


class IntentJudge:
    """LLM-based intent classification and query extraction.

    This judge receives full context about the conversation and makes
    intelligent decisions about:
    1. Whether speech is directed at the assistant
    2. What the actual query is (excluding echo, pre-wake-word chatter, filler)
    3. Whether this is a stop command

    Uses a small model (gemma4) for better accuracy compared to
    the simpler intent_validator.
    """

    SYSTEM_PROMPT_TEMPLATE = '''You are the intent judge for voice assistant "{name}".

Two modes:

WAKE WORD MODE:
- Extract complete query from segment containing "{name}" — may be a question, plain declarative statement (e.g. "{name} I just ate a burger", "{name} I'm tired"), or command/imperative (e.g. "set a timer", "remind me to...", "play music"). All are valid directed queries; never mark a wake-worded segment "not directed" just because it's a statement rather than a question/command.
- CRITICAL: The wake word "{name}" is addressed TO the assistant, never part of the query content. Remove every occurrence of "{name}" from the extracted query, whether it appears at the start, end, or middle of the sentence — including when it sits next to a named entity (e.g. "movie called Possessor Jarvis" → the film is "Possessor", not "Possessor Jarvis"). Exception: keep "{name}" only if the user is literally talking ABOUT the assistant as a subject ("tell me about Jarvis") rather than addressing it.
- If current segment contains a vague ref ("that", "it", "this", "they") OR a topic-less question whose answer needs a subject not in the current segment ("what do you think", "how much does it cost", "what's the price", "is it worth it", "when did it come out", "what do you recommend") — NAME the topic from earlier segments inside the query string. Do NOT output the vague/open form literally.
- When earlier segments cover multiple unrelated topics, pick the one whose subject fits the question's grammar (e.g. "what's the price" -> a purchasable thing, not a sports game). Ignore unrelated threads.
- Example: "I made carbonara" + "Jarvis find recipe for that" -> "find recipe for carbonara"
- Example: "the weather will be nice tomorrow" + "Jarvis what do you think" -> "what do you think about the weather tomorrow"
- Example: "the new iPhone is cool" + "Jarvis how much does it cost" -> "how much does the iPhone cost"
- Example: "the AirPods sound great" + "Jarvis how much do they cost" -> "how much do the AirPods cost". NOT "how much do they cost" — pronoun MUST be replaced with the named topic in the output query even if you resolved it correctly in your reasoning.
- Example: "did you catch the ball game" + "the new iPhone is out" + "I want the pro model" + "Jarvis what's the price" -> "what's the price of the iPhone pro model". NOT "what's the price of the pro model" (which pro model? ambiguous) — always prepend the brand/parent from earlier segments.
- If standalone imperative command ("answer that", "respond to that", "reply to that", "address that", "answer my question", "go ahead and answer") NOT a question -> re-issue prior question
  Variants: "answered that", "answers that", "answering that" = same imperative (Whisper tense errors)
  Exception: If segment has BOTH imperative + new question -> new question wins
  This rule ONLY applies to imperatives that explicitly reference a prior thing ("that", "my question", "answer"). Self-contained imperatives with open subjects ("say something", "tell me a joke", "tell me anything", "give me advice", "surprise me") are valid queries — pass them through literally, do NOT treat them as vague or as needing a prior question.
- Query must be answerable alone (without the transcript). When resolving to a sub-item ("pro model", "the red one"), also include the parent noun/brand from earlier segments — "pro model" alone is not self-contained; "iPhone pro model" is.

HOT WINDOW MODE (no wake word needed):
- User IS DIRECTED (directed=true) — always. This overrides any "topic-less question" heuristic above; follow-ups like "tell me more" are directed in hot window.
- Extract from segments WITHOUT "(during TTS)" marker
- Question or statement both valid

ECHO / MARKER RULES:
- "(during TTS)" = echo of assistant -> skip, never extract
- "(CURRENT - JUDGE THIS)" = segment to judge now
- Use earlier segments to resolve references only, not as query source

TRANSCRIPT NOISE:
- Segments come from Whisper ASR and may contain mishearings: wrong homophones (to/too/two), tense slips (answered/answer), substituted similar-sounding words, fused word boundaries ("ever ist" for "Everest"), or short nonsense fillers. None of this changes the rules above — it is a reminder that a segment looking malformed or off-topic is often noise to skip past, not a topic to anchor on.
- When such a segment sits between a real question and an imperative wake-word call, treat it as noise and still re-issue the original question (see the Mount Everest + chatter + "answer that" example below).
- Within the extracted query string, fix obvious ASR slips quietly (tense, fused words, homophones) so the query is answerable; do NOT rewrite content or change the user's intent.

STOP DETECTION:
- "stop", "quiet" (standalone or short command) -> directed=true, stop=true, query=""

NOT DIRECTED:
- No wake word AND not hot window -> directed=false
- Wake word used only as a narrative mention ("I told my friend about {name}") -> directed=false
- (INVALID) "statement about [topic], not a command or question" — with the wake word present to ADDRESS {name}, EVERY statement is directed. "Not a command or question" is never a valid reason for directed=false. Only the two rules above are valid reasons.

Output JSON only:
{{"directed": true/false, "query": "...", "stop": true/false, "confidence": "high/medium/low", "reasoning": "brief"}}

Examples:
- "Jarvis what time is it" -> {{"directed": true, "query": "what time is it", "stop": false, "confidence": "high", "reasoning": "wake word + question"}}
- "what do you know about the movie called Possessor Jarvis" -> {{"directed": true, "query": "what do you know about the movie called Possessor", "stop": false, "confidence": "high", "reasoning": "wake word at end; entity is Possessor, not Possessor Jarvis"}}
- "I just ate a big Mac Jarvis" -> {{"directed": true, "query": "I just ate a big Mac", "stop": false, "confidence": "high", "reasoning": "wake word at end; 'Mac' is part of the brand name 'Big Mac', not a compound surname with Jarvis"}}
- "hey Jarvis what's the weather in London" -> {{"directed": true, "query": "what's the weather in London", "stop": false, "confidence": "high", "reasoning": "wake word removed from mid-sentence position"}}
- "Jarvis say something please" -> {{"directed": true, "query": "say something please", "stop": false, "confidence": "high", "reasoning": "self-contained imperative"}}
- "Jarvis tell me a joke" -> {{"directed": true, "query": "tell me a joke", "stop": false, "confidence": "high", "reasoning": "self-contained imperative"}}
- Previous "dinosaurs are cool" + Current "Jarvis what do you think about that" -> {{"directed": true, "query": "what do you think about dinosaurs being cool", "stop": false, "confidence": "high", "reasoning": "resolved 'that' to dinosaurs"}}
- Previous "How's the weather?" + Current "Jarvis answer that" -> {{"directed": true, "query": "how is the weather", "stop": false, "confidence": "high", "reasoning": "imperative -> re-issue prior question"}}
- Previous "How tall is Mount Everest" + Noise "some unrelated chatter" + Current "Jarvis answer that" -> {{"directed": true, "query": "how tall is Mount Everest", "stop": false, "confidence": "high", "reasoning": "imperative -> re-issue prior QUESTION; ignore the chatter segment, re-issue the original question even when noise sits between"}}
- Previous "What's the capital of Portugal" + Current "Jarvis go ahead and answer" -> {{"directed": true, "query": "what is the capital of Portugal", "stop": false, "confidence": "high", "reasoning": "multi-word imperative ('go ahead and answer') is the same pattern as 'answer that' -> re-issue prior question; do NOT pass the imperative through literally"}}
- Hot window, user says "I think absurdism is better" -> {{"directed": true, "query": "I think absurdism is better", "stop": false, "confidence": "high", "reasoning": "user statement in hot window"}}
- "(during TTS)" segments only -> {{"directed": false, "query": "", "stop": false, "confidence": "high", "reasoning": "only echo"}}
- "stop" -> {{"directed": true, "query": "", "stop": true, "confidence": "high", "reasoning": "stop command"}}
- "Yeah, the light is very bright but the heat isn't too bad this week honestly Jarvis" -> {{"directed": true, "query": "Yeah, the light is very bright but the heat isn't too bad this week honestly", "stop": false, "confidence": "high", "reasoning": "wake word + statement about weather — directed"}}
- No wake word, not hot window -> {{"directed": false, "query": "", "stop": false, "confidence": "high", "reasoning": "no wake word"}}'''

    def __init__(self, config: Optional[IntentJudgeConfig] = None):
        """Initialize the intent judge.

        Args:
            config: Configuration for the judge
        """
        self.config = config or IntentJudgeConfig()
        self._last_error_time: float = 0.0
        self._error_cooldown: float = 30.0
        self._last_failure_reason: str = ""

    @property
    def last_failure_reason(self) -> str:
        """Human-readable reason the most recent judge() call failed, if any."""
        return self._last_failure_reason

    @property
    def available(self) -> bool:
        """Check if intent judge is available."""
        if time.time() - self._last_error_time < self._error_cooldown:
            return False
        return True

    def _build_system_prompt(self) -> str:
        """Build the system prompt with configuration."""
        return self.SYSTEM_PROMPT_TEMPLATE.format(name=self.config.assistant_name)

    def _normalize_aliases(self, text: str) -> str:
        """Replace wake-word aliases with the primary assistant name.

        Aliases are Whisper mishearings of the wake word (e.g. "Jervis",
        "Jaivis"). Without normalisation the small judge model sees "Jervis"
        in the transcript, doesn't know it refers to {name}, and may decide
        the user is addressing a different person.
        """
        if not text or not self.config.aliases:
            return text
        # Longest-first avoids a shorter alias matching inside a longer one.
        for alias in sorted(self.config.aliases, key=len, reverse=True):
            if not alias:
                continue
            pattern = r"\b" + re.escape(alias) + r"\b"
            text = re.sub(pattern, self.config.assistant_name, text, flags=re.IGNORECASE)
        return text

    def _build_user_prompt(
        self,
        segments: List[TranscriptSegment],
        wake_timestamp: Optional[float],
        last_tts_text: str,
        last_tts_finish_time: float,
        in_hot_window: bool,
        current_text: str = "",
    ) -> str:
        """Build the user prompt with full context.

        Args:
            segments: Recent transcript segments
            wake_timestamp: When wake word was detected (None if hot window)
            last_tts_text: What TTS last said
            last_tts_finish_time: When TTS finished
            in_hot_window: Whether we're in hot window mode
            current_text: The text that triggered this intent judgment (for marking)

        Returns:
            Formatted prompt for the LLM
        """
        lines = ["Transcript:"]

        # Find the segment matching current_text (normalize for comparison)
        current_text_lower = current_text.lower().strip() if current_text else ""

        for seg in segments:
            # Skip processed segments entirely - they already had queries extracted
            # The dialogue memory has context from those processed turns
            is_current_segment = current_text_lower and seg.text.lower().strip() == current_text_lower
            if seg.processed and not is_current_segment:
                continue

            ts = seg.format_timestamp()
            markers = []

            if seg.is_during_tts:
                markers.append("during TTS")
            if wake_timestamp and seg.start_time <= wake_timestamp <= seg.end_time:
                markers.append("WAKE WORD DETECTED")
            # Mark the current segment being judged (match by text content)
            if is_current_segment:
                markers.append("CURRENT - JUDGE THIS")

            marker_str = f" ({', '.join(markers)})" if markers else ""
            display_text = self._normalize_aliases(seg.text)
            lines.append(f'[{ts}]{marker_str} "{display_text}"')

        if not segments:
            lines.append("(no speech)")

        lines.append("")

        # Wake word info
        if in_hot_window:
            lines.append("Mode: HOT WINDOW (listening for follow-up, no wake word needed)")
        elif wake_timestamp:
            from datetime import datetime
            wake_ts_str = datetime.fromtimestamp(wake_timestamp).strftime('%H:%M:%S.%f')[:-3]
            lines.append(f"Wake word detected at: {wake_ts_str}")
        else:
            lines.append("Mode: WAKE WORD (waiting for wake word)")

        # TTS info
        lines.append("")
        if last_tts_text:
            from datetime import datetime
            tts_ts_str = datetime.fromtimestamp(last_tts_finish_time).strftime('%H:%M:%S') if last_tts_finish_time > 0 else "unknown"
            lines.append(f'Last TTS output: "{last_tts_text[:200]}{"..." if len(last_tts_text) > 200 else ""}"')
            lines.append(f"TTS finished at: {tts_ts_str}")
        else:
            lines.append("Last TTS: None")

        return "\n".join(lines)

    def _parse_response(self, response_text: str) -> Optional[IntentJudgment]:
        """Parse the LLM response into a judgment.

        Args:
            response_text: Raw response from the LLM

        Returns:
            IntentJudgment or None if parsing failed
        """
        # Locate the outermost JSON object by brace-matching. This handles
        # markdown code fences and JSON whose string values contain braces
        # — cases the old `\{[^{}]*\}` regex missed.
        json_text = _extract_json_object(response_text)
        if not json_text:
            debug_log(f"intent judge: no JSON found in response: {response_text[:100]}", "voice")
            return None

        try:
            data = json.loads(json_text)

            # Alias normalisation also applies to the output query: the judge
            # occasionally echoes a misheard wake word back verbatim ("Chavis"
            # stayed in the transcript, judge emitted it in the query), which
            # then leaks into the reply engine's memory search and prompts.
            raw_query = str(data.get("query", "")).strip()
            normalized_query = self._normalize_aliases(raw_query)

            return IntentJudgment(
                directed=bool(data.get("directed", False)),
                query=normalized_query,
                stop=bool(data.get("stop", False)),
                confidence=str(data.get("confidence", "low")).lower(),
                reasoning=str(data.get("reasoning", "")),
                raw_response=response_text,
            )
        except (json.JSONDecodeError, KeyError) as e:
            debug_log(f"intent judge: failed to parse response: {e}", "voice")
            return None

    def warm_up(self) -> bool:
        """Page the configured judge model into the active backend."""
        return warm_up_chat_model(
            self.config.cfg,
            self.config.model,
            timeout=max(self.config.timeout_sec, 60.0),
        )

    def judge(
        self,
        segments: List[TranscriptSegment],
        wake_timestamp: Optional[float] = None,
        last_tts_text: str = "",
        last_tts_finish_time: float = 0.0,
        in_hot_window: bool = False,
        current_text: str = "",
    ) -> Optional[IntentJudgment]:
        """Judge whether speech is directed at assistant and extract query.

        Args:
            segments: Recent transcript segments
            wake_timestamp: When wake word was detected (None if hot window/text-based)
            last_tts_text: What TTS last said (for echo detection)
            last_tts_finish_time: When TTS finished
            in_hot_window: Whether we're in hot window mode
            current_text: The text that triggered this judgment (for marking current segment)

        Returns:
            IntentJudgment or None if judgment failed
        """
        if not self.available:
            return None

        if not segments:
            return None

        try:
            system_prompt = self._build_system_prompt()
            user_prompt = self._build_user_prompt(
                segments,
                wake_timestamp,
                last_tts_text,
                last_tts_finish_time,
                in_hot_window,
                current_text,
            )

            # Log input
            mode = "hot_window" if in_hot_window else "wake_word"
            transcript_preview = "; ".join(s.text[:30] for s in segments[-3:])
            debug_log(f"🧠 Intent judge [{mode}]: \"{transcript_preview}...\"", "voice")

            # Voice sessions can have long quiet stretches; the Ollama
            # ``keep_alive`` keeps the judge model resident between
            # engagements so we don't pay the cold-reload tax on each one.
            # ``num_ctx: 8192`` covers a ~2k-token system prompt plus up to
            # ~2 minutes of multi-speaker transcript without truncating the
            # prompt tail. Both knobs are silently dropped on backends
            # without an unloading concept (OpenAI-compatible servers).
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            try:
                resp = get_llm_backend(self.config.cfg).chat(
                    self.config.model,
                    messages,
                    timeout_sec=self.config.timeout_sec,
                    extra_options={
                        "temperature": 0.0,
                        # Reasoning models count thinking tokens against
                        # this cap, so it must cover reasoning + the JSON
                        # answer. Too tight a cap truncates ``content``
                        # mid-JSON on complex transcripts and the whole
                        # judgment is lost (500 cut this exact case off at
                        # "I said tomorro"). 1500 gives ~4.5x headroom over
                        # the measured 326-token reasoning+answer baseline
                        # while ``intent_judge_timeout_sec`` (6s default)
                        # still bounds slow or runaway generations; the
                        # model normally stops long before the cap.
                        "max_tokens": 1500,
                        "num_ctx": 8192,
                        "keep_alive": _ollama_keep_alive_for_power_mode(
                            self.config.cfg
                        ),
                    },
                    thinking=self.config.thinking,
                )
            except Exception as e:
                self._last_failure_reason = f"request error: {type(e).__name__}"
                debug_log(f"intent judge: {self._last_failure_reason}", "voice")
                self._last_error_time = time.time()
                return None

            if not isinstance(resp, dict):
                # ``chat()`` returns ``None`` on transient HTTP errors and
                # timeouts. Don't back off — voice is high-turn and a single
                # 503 must not kill the next 30s of intent judging.
                self._last_failure_reason = "no response from backend"
                debug_log(f"intent judge: {self._last_failure_reason}", "voice")
                return None

            message = resp.get("message")
            response_text = ""
            if isinstance(message, dict):
                content = message.get("content")
                if isinstance(content, str):
                    response_text = content

            judgment = self._parse_response(response_text)

            # Reasoning models (e.g. Qwen3.5 / Gemma 4 e2b on LM Studio)
            # put their thinking in ``reasoning_content`` and the answer in
            # ``content`` — but the shared token cap can truncate ``content``
            # mid-JSON (or leave it empty) when the thinking runs long. The
            # model usually ends its thinking with the full JSON answer, so
            # recover it from the reasoning text when content did not parse.
            # The last balanced object wins — the answer comes after any
            # earlier echoes of the system prompt's JSON example.
            if judgment is None and isinstance(message, dict):
                reasoning = message.get("reasoning_content")
                if isinstance(reasoning, str):
                    extracted = _extract_json_object(reasoning, last=True)
                    if extracted:
                        recovered = self._parse_response(extracted)
                        if recovered is not None:
                            judgment = recovered
                            response_text = extracted

            if judgment is None and not response_text:
                # Ollama's /api/generate returned ``response``; chat() shape
                # surfaces content under ``message.content``. Some adapters
                # may still expose a top-level ``response`` field — accept
                # it as a fallback rather than reject the call.
                fallback = resp.get("response")
                if isinstance(fallback, str):
                    response_text = fallback
                    judgment = self._parse_response(response_text)

            if judgment:
                self._last_failure_reason = ""
                direction = "✅ DIRECTED" if judgment.directed else "❌ NOT DIRECTED"
                stop_str = " [STOP]" if judgment.stop else ""
                query_str = f" → \"{judgment.query}\"" if judgment.query else ""
                debug_log(
                    f"🧠 Intent judge: {direction} ({judgment.confidence}){stop_str}{query_str}",
                    "voice"
                )
                debug_log(f"   Reasoning: {judgment.reasoning}", "voice")
            else:
                self._last_failure_reason = f"unparseable response: {response_text[:80]}"
                debug_log(f"🧠 Intent judge: failed to parse: {response_text[:100]}", "voice")

            return judgment

        except Exception as e:
            self._last_failure_reason = f"error: {type(e).__name__}"
            debug_log(f"intent judge: {self._last_failure_reason}", "voice")
            return None


def create_intent_judge(cfg) -> IntentJudge:
    """Build an :class:`IntentJudge` bound to the Jarvis settings.

    The judge dispatches every chat call through ``get_llm_backend(cfg)``,
    so the active provider (Ollama / OpenAI-compatible) handles the wire
    shape automatically.
    """
    config = IntentJudgeConfig(
        assistant_name=str(getattr(cfg, "wake_word", "jarvis")).capitalize(),
        aliases=list(getattr(cfg, "wake_aliases", [])),
        model=resolve_model(cfg, Tier.FAST),
        cfg=cfg,
        timeout_sec=float(getattr(cfg, "intent_judge_timeout_sec", 6.0)),
        thinking=bool(getattr(cfg, "intent_judge_thinking_enabled", False)),
    )
    return IntentJudge(config)
